Tous les fichiers pr�sents dans cette archive, hormis ce fichier et les fichiers "LICENSE",
sont des versions alt�r�es des fichiers originaux de leurs auteurs respectifs.
Les modifications ont pour but de corriger quelques oublis dans FreeLAN 
(Protection du chemin d'acc�s au service, correction d'un bug de "type ind�fini" 
li� � la gestion de l'IPV6 par WinSock avec l'include de WS2tcpip.h...)
et de permettre la compilation "x64" optimis�e et enti�rement statique de FreeLAN,
et des diff�rentes librairies qui lui sont n�cessaires.

Le guide de compilation est disponible sur�:
https://github.com/TJ-59/Building-FreeLAN